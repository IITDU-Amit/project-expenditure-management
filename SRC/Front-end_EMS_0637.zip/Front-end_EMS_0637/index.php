<!DOCTYPE html>
<?php
  $page = $_GET['page'];
?>
<html>
<head>
    <!-- Basic Page Needs
    ================================================== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <title>EMS :Home</title>
    <link rel="shortcut icon" href="LP-logo.PNG" type="image/png">

    <!-- Mobile Specific Metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- CSS
    ================================================== -->
    <!-- LOGIN css file-->
    <link rel="stylesheet" href="css/login_reset.css">
    <link rel="stylesheet" href="css/login_style.css">
    <!-- Bootstrap css file-->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Font awesome css file-->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Superslide css file-->
    <link rel="stylesheet" href="css/superslides.css">
    <!-- Slick slider css file -->
    <link href="css/slick.css" rel="stylesheet"> 
    <!-- Circle counter cdn css file -->
    <link rel='stylesheet prefetch' href='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/css/jquery.circliful.css'>  
    <!-- smooth animate css file -->
    <link rel="stylesheet" href="css/animate.css"> 
    <!-- preloader -->
    <link rel="stylesheet" href="css/queryLoader.css" type="text/css" />
    <!-- gallery slider css -->
    <link type="text/css" media="all" rel="stylesheet" href="css/jquery.tosrus.all.css" />    
    <!-- Default Theme css file -->
    <link id="switcher" href="css/themes/default-theme.css" rel="stylesheet">
    <!-- Main structure css file -->
    <link href="style.css" rel="stylesheet">
   
    <!-- Google fonts -->
    <link href='http://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet' type='text/css'>   
    <link href='http://fonts.googleapis.com/css?family=Varela' rel='stylesheet' type='text/css'>    

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
 
 <!-- <link rel="stylesheet" type="text/css" href="CSS/StyleForIndex.css">-->
</head>
<body>
<!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"></a>
    <!-- END SCROLL TOP BUTTON -->
    <?php
    if($page == "login"){
        include('header_1.php');
        include('login.php');
    }
    elseif ($page == "AboutUs") {
      include('header_1.php');
      include('AboutUs.php');
      include('footer.php');
      
    }
    elseif ($page=="Contact") {
      include('header_1.php');
      include('Contact.php');
      include('footer.php');
    }
    elseif ($page=="assign_field") {
      include('header_1.php');
      include('assign_field.php');
      include('footer.php');
    }
    elseif ($page=="sector_admin") {
      include('header_1.php');
      include('sector_admin.php');
      include('footer.php');
    }
    elseif ($page=="proposal_sub") {
      include('header_1.php');
      include('proposal_sub.php');
      include('footer.php');
    }
    elseif ($page=="sector_sub") {
      include('header_1.php');
      include('sector_sub.php');
      include('footer.php');
    }
    elseif ($page=="field_report") {
      include('header_1.php');
      include('field_report.php');
      include('footer.php');
    }
    elseif ($page=="field_admin1") {
      include('header_1.php');
      include('field_admin1.php');
      include('footer.php');
    }
    elseif ($page=="tebular_sector") {
      include('header_1.php');
      include('tebular_sector.php');
      include('footer.php');
    }
    elseif ($page=="sub_admin") {
      include('header_1.php');
      include('sub_admin.php');
      include('footer.php');
    }
    elseif ($page=="field_sub") {
      include('header_1.php');
      include('field_sub.php');
      include('footer.php');
    }
    elseif ($page=="proposal_admin") {
      include('header_1.php');
      include('proposal_admin.php');
      include('footer.php');
    }
    elseif ($page=="teacher_details") {
      include('header_1.php');
      include('teacher_details.php');
      include('footer.php');
    }
    elseif ($page=="proposal_field") {
      include('header_1.php');
      include('proposal_field.php');
      include('footer.php');
    }
    elseif ($page=="add_proposal") {
      include('header_1.php');
      include('add_proposal.php');
      include('footer.php');
    }
    elseif ($page=="final_proposal") {
      include('header_1.php');
      include('final_proposal.php');
      include('footer.php');
    }
    else {
        
      include('header_1.php');
      include('slider.php');
      include('homepage_content.php');
      //include('our_courses.php');
      //include('tutors.php');
      //include('student_testimonial.php');
      include('footer.php');
       
    }
    ?>

    <!-- Javascript Files
    ================================================== -->

    <!-- initialize jQuery Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Preloader js file -->
    <script src="js/queryloader2.min.js" type="text/javascript"></script>
    <!-- For smooth animatin  -->
    <script src="js/wow.min.js"></script>  
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="js/slick.min.js"></script>
    <!-- superslides slider -->
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.animate-enhanced.min.js"></script>
    <script src="js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>   
    <!-- for circle counter -->
    <script src='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/js/jquery.circliful.min.js'></script>
    <!-- Gallery slider -->
    <script type="text/javascript" language="javascript" src="js/jquery.tosrus.min.all.js"></script>   
   
    <!-- Custom js-->
    <script src="js/custom.js"></script>

</body>
</html>
