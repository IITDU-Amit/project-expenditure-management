<?php
/**
 * Created by PhpStorm.
 * User: nazmul
 * Date: 4/30/16
 * Time: 6:57 PM
 */

include'../db.php';
session_start();


if (isset($_POST['login'])){
    $username = $_POST['username1'];
    $password = $_POST['pwd1'];
    //echo $username;
    //echo $password;
    /*if($username=='Admin' && $password=='Admin123'){
        //echo "Thank you admin.";
        include '../admin/index.php';

    }*/

        $sql= "SELECT * FROM User WHERE username='$username'";

        //$result = mysql_query($sql) or die(mysql_error());
        //$rows = mysql_num_rows($result);

        $result = mysqli_query($db,$sql) or die('failed');
        $row = mysqli_fetch_assoc($result) or die('failed again.');
        //echo $row['password'];

        if($row['password']==$password){

            $_SESSION['login_user_id']=$row['user_id'];
            $_SESSION['login_user_status']=$row['role'];

            header ("Location: ../index.php");

        }
       /* else if ($row['password']==$password && $row['designation']=='instructor') {
            $_SESSION['login_username']=$row['username'];
            $_SESSION['login_password']=$row['password'];
            $_SESSION['login_designation']=$row['designation'];
        }
        else if ($row['password']==$password && $row['designation']=='admin'){

            $_SESSION['login_username']=$row['username'];
            $_SESSION['login_password']=$row['password'];
            $_SESSION['login_designation']=$row['designation'];
            
            
        } */
        else {
            header("Location: ../index.php?page=login");
        }

}
?>