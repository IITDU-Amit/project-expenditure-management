/**
 * Created by nazmul on 4/30/16.
 */

function checklogin(form) {

    if(form.username1.value == "" || form.username1.value==null) {
        alert("Error: Username cannot be blank!");
        form.username1.focus();
        return false;
    }
    if (form.pwd1.value == null || form.pwd1.value == "") {
        alert("Error:password must be provided !");
        return false;
    }
    
    return true;
    
}