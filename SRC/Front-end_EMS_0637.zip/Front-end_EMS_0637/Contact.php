<div class="container-fluid" style="padding-top: 130px">
  <p>For emergency contact:</p>
   <table class="table table-striped">
    <thead>
      <tr>
        <th>Name</th>
        <th>Cell Phone</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Feroze Al Mamun Sagor</td>
        <td>+8801753407705</td>
        <td>bsse0634@iit.du.ac.bd</td>
      </tr>
      <tr>
        <td>M. A. Nur Quraishi</td>
        <td>+8801733999551</td>
        <td>bsse0615@iit.du.ac.bd</td>
      </tr>
	  <tr>
        <td>Md. Abu Bakar Siddique Tamim</td>
        <td>+8801521494162</td>
        <td>bsse0609@iit.du.ac.bd</td>
      </tr>
      <tr>
        <td>Munsi Toufiqur Rahman</td>
        <td>+8801916266522</td>
        <td>bsse0636@iit.du.ac.bd</td>
      </tr>
	  <tr>
        <td>Md. Nazmul Haque Shaikat</td>
        <td>+8801611724568</td>
        <td>bsse0637@iit.du.ac.bd</td>
      </tr>
    </tbody>
  </table>
</div>
