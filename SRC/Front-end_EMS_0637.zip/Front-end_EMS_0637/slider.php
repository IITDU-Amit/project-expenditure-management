<!--=========== BEGIN SLIDER SECTION ================-->
<section id="slider" class="carousel slide" data-ride="carousel">
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="slider_area">
                <!-- Start super slider -->
                <div id="slides">
                    <ul class="slides-container">
                        
                        <!-- Start single slider-->
                        <li>
                            <img src="img/slider/iit2.jpg" alt="img">
                            <div class="slider_caption slider_right_caption">
                                <h2>Expenditure Management System</h2>
                                <p>Expenditure management System(EMS) for IIT is designed for managing expenditure of IIT.</p>
                                
                            </div>
                        </li>
                        <!-- Start single slider-->
                        <li>
                            <img src="img/slider/iit3.jpg" alt="img">
                            <div class="slider_caption">
                                <h2>Helping hand to manage expenditure management</h2>
                                <p>Our system is for managing expenditure of Institute of Information Technology(IIT), University of Dhaka.</p>
                            </div>
                        </li>
                    </ul>
                    <nav class="slides-navigation">
                        <a href="#" class="next"></a>
                        <a href="#" class="prev"></a>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>
<!--=========== END SLIDER SECTION ================-->

