<div class="container-fluid" style="padding-top: 130px">
    <center>Powered By:</center>
  <a href="http://www.iit.du.ac.bd/"> <center> <img src="Images/logo.jpg" class="img-circle" width="100px" height="100px" align="middle"></center></a>
</div>

    <div class="container-fluid" style="width: 100%;background-color: #d5d5d5">
    <center><p>&copy; -2016 IIT, University of Dhaka</p></center>
</div>
