<!--=========== BEGIN HEADER SECTION ================-->

<?php

if(!isset($_SESSION)){
    session_start();
}
?>
<header id="header">
    <!-- BEGIN MENU -->
    <div class="menu_area">
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation"> 
            <div class="container">
                <div class="navbar-header">
                    <!-- FOR MOBILE VIEW COLLAPSED BUTTON -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <!-- LOGO -->
                    <!-- TEXT BASED LOGO -->
                    <a class="navbar-brand" href="index.php">EMS</a>
                    <!-- IMG BASED LOGO  -->
                    <!-- <a class="navbar-brand" href="index.html"><img src="img/logo.png" alt="logo"></a>  -->

                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul id="top-menu" class="nav navbar-nav navbar-left main-nav">
                        <li><a id="home" href="index.php">Home</a></li>
                       <li><a id="AboutUs" href="index.php?page=AboutUs">About Us</a></li>
                       <li><a id="sector_sub" href="index.php?page=sector_sub">Sector</a></li>
                       <li><a id="sector_admin" href="index.php?page=sector_admin">Sector</a></li>
                       <li><a id="subadmin" href="index.php?page=sub_admin">Sub Admin</a></li>
                       <li><a id="proposal_sub" href="index.php?page=proposal_sub">Proposal</a></li>
                       <li><a id="proposal_admin" href="index.php?page=proposal_admin">Proposal</a></li>
                       <li><a id="report" href="index.php?page=tebular_sector">Report</a></li>
                        <!--<li class="dropdown">
                            <a id="report" href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Report<span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a id="tabular_details" href="index.php?page=tebular_sector">Tabular Details</a></li>
                                <li><a id="graphical_representation" href="#">Graphical Representation</a></li>
                            </ul>
                        </li> -->
                     
                        
                        
                        
                       <li><a id="Contact" href="index.php?page=Contact">Contact</a></li>
                    </ul>
                    <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
                        <li><a id="login" href="index.php?page=login"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                        <li class="dropdown">
                            <a id="pro_set_log" href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span class="glyphicon glyphicon-user"></span><span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a id="profile" href="#">Profile</a></li>
                                <li><a id="logout" href="http://localhost/EMS_Project/authentication/logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div><!--/.nav-collapse -->
            </div>
        </nav>
    </div>
    
    <!-- END MENU -->
</header>

<script type="text/javascript">
    document.getElementById("sector_sub").style.display='none';
    document.getElementById("sector_admin").style.display='none';
    document.getElementById("subadmin").style.display='none';
    document.getElementById("proposal_sub").style.display='none';
    document.getElementById("proposal_admin").style.display='none';
    document.getElementById("report").style.display='none';
    document.getElementById("pro_set_log").style.display='none';
    
</script>

<script type="text/javascript">

     var user_status_check ="<?php echo $_SESSION['login_user_status']; ?>";
     var user_id_check="<?php echo $_SESSION['login_user_id'];?>"

     if(user_status_check=='Director'){
         document.getElementById("home").style.display='block';
         document.getElementById("sector_admin").style.display='block';
         document.getElementById("report").style.display='block';
         document.getElementById("subadmin").style.display='block';
         document.getElementById("proposal_admin").style.display='block';
         document.getElementById("pro_set_log").style.display='block';
         document.getElementById("login").style.display='none';
         document.getElementById("AboutUs").style.display='none';
         document.getElementById("Contact").style.display='none';
         document.getElementById("sector_sub").style.display='none';
         document.getElementById("proposal_sub").style.display='none';
         //document.getElementById("edit_assignment").style.display='none';
         //document.getElementById("generate_guiz").style.display='none';
         //document.getElementById("evaluate_assignment").style.display='none';
         
     }
     else if(user_status_check=='Teacher'){
         document.getElementById("home").style.display='block';
         document.getElementById("sector_admin").style.display='none';
         document.getElementById("report").style.display='none';
         document.getElementById("subadmin").style.display='none';
         document.getElementById("proposal_admin").style.display='none';
         document.getElementById("pro_set_log").style.display='block';
         document.getElementById("login").style.display='none';
         document.getElementById("AboutUs").style.display='none';
         document.getElementById("Contact").style.display='none';
         document.getElementById("sector_sub").style.display='block';
         document.getElementById("proposal_sub").style.display='block';
     }
     
</script>

<!--=========== END HEADER SECTION ================-->
