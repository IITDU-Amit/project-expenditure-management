
<div class="container-fluid"style="padding-top: 130px">
  <p id="about">This website is developed by the students of BSSE 6th batch, IIT, University of Dhaka</p>
   <table class="table table-striped">
    <thead>
      <tr>
        <th>Name</th>
        <th>Roll</th>
        <th>Hometown</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Feroze Al Mamun Sagor</td>
        <td>0634</td>
        <td>Rangpur</td>
      </tr>
      <tr>
        <td>M. A. Nur Quraishi</td>
        <td>0615</td>
        <td>Thakurgaon</td>
      </tr>
	  <tr>
        <td>Md. Abu Bakar Siddique Tamim</td>
        <td>0609</td>
        <td>Dhaka</td>
      </tr>
      <tr>
        <td>Munsi Toufiqur Rahman</td>
        <td>0636</td>
        <td>Rajbari</td>
      </tr>
	  <tr>
        <td>Md. Nazmul Haque Shaikat</td>
        <td>0637</td>
        <td>Sirajganj</td>
      </tr>
    </tbody>
  </table>
</div>
