/**
 * Created by nazmul on 4/30/16.
 */


$("#sub").click( function () {

    $.post( $("#reg").attr("action"), $("#reg:input").serializeArray(), function (info) { $("#result").html(info);
    });
    clearInput();
    }
);
$("#reg").submit( function () {
    return false;
});

function clearInput() {
   $("#reg:input").each( function () {
       $(this).val('');
   });
}