<div class="login-container">

    <div class="form">
        <div class="thumbnail"><img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/169963/hat.svg"/></div>

        <p id="demo"></p>

        <span id="result"> </span>

        <form class="login-form" name="login_form" action="authentication/logincheck.php" method="post"
              onsubmit="return checklogin(this)">
            <input type="text" name="username1" placeholder="username"/>
            <input type="password" name="pwd1" placeholder="password"/>
            <button type="submit" name="login"  >Login</button>
        </form>

    </div>
</div>

<script src="authentication/sign_js/checklogin.js"></script>


<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

<script src="js/login.js"></script>
